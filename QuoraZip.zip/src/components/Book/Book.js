import React from 'react';

function Book() {
    return <div>hello from book</div>;
}

export default Book;
