import React from 'react';

function Home() {
    return <div>hello from home</div>;
}

export default Home;
