import React from 'react';

function Navbar() {
    return <div>hello from navbar</div>;
}

export default Navbar;
