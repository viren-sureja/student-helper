import React from 'react';

function SpiCpi() {
    return <div>hello from spicpi</div>;
}

export default SpiCpi;
